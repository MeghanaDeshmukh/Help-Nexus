"use client";
import { useState, useRef, useEffect } from "react";

const BOT_NAME = "AI Assistant";

const SYSTEM_PROMPT = `You are a helpful AI assistant for a business website. You help visitors with:
- General questions and conversation
- Customer support inquiries
- Answering FAQs
- Capturing lead information (name, email, what they need)
Be concise, friendly, and professional. If someone seems interested in your services, gently ask for their name and email to follow up.`;

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Hey there 👋 How can I help you today?" },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, open]);

  async function sendMessage() {
    const text = input.trim();
    if (!text || loading) return;

    const newMessages = [...messages, { role: "user", content: text }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: newMessages.slice(1), // exclude initial greeting
          systemPrompt: SYSTEM_PROMPT,
        }),
      });
      const data = await res.json();
      setMessages([...newMessages, { role: "assistant", content: data.reply }]);
    } catch {
      setMessages([
        ...newMessages,
        { role: "assistant", content: "Sorry, something went wrong. Please try again." },
      ]);
    } finally {
      setLoading(false);
    }
  }

  function handleKey(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');

        .cw-root * { box-sizing: border-box; margin: 0; padding: 0; }

        .cw-root {
          font-family: 'DM Sans', sans-serif;
          position: fixed;
          bottom: 28px;
          right: 28px;
          z-index: 9999;
        }

        /* FAB Button */
        .cw-fab {
          width: 60px;
          height: 60px;
          border-radius: 16px;
          background: #0a0a0a;
          border: none;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 8px 32px rgba(0,0,0,0.3), 0 2px 8px rgba(0,0,0,0.2);
          transition: transform 0.2s cubic-bezier(.34,1.56,.64,1), box-shadow 0.2s;
          position: relative;
          overflow: hidden;
        }
        .cw-fab::before {
          content: '';
          position: absolute;
          inset: 0;
          background: linear-gradient(135deg, #e8ff47 0%, #00e5ff 100%);
          opacity: 0;
          transition: opacity 0.2s;
        }
        .cw-fab:hover { transform: scale(1.08); box-shadow: 0 12px 40px rgba(0,0,0,0.4); }
        .cw-fab:hover::before { opacity: 1; }
        .cw-fab svg { position: relative; z-index: 1; transition: color 0.2s; }
        .cw-fab:hover svg { color: #0a0a0a !important; }

        /* Notification dot */
        .cw-dot {
          position: absolute;
          top: 8px; right: 8px;
          width: 10px; height: 10px;
          background: #e8ff47;
          border-radius: 50%;
          border: 2px solid #0a0a0a;
          animation: cw-pulse 2s infinite;
        }
        @keyframes cw-pulse {
          0%, 100% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.3); opacity: 0.7; }
        }

        /* Window */
        .cw-window {
          position: absolute;
          bottom: 72px;
          right: 0;
          width: 370px;
          height: 520px;
          background: #0a0a0a;
          border-radius: 24px;
          display: flex;
          flex-direction: column;
          overflow: hidden;
          box-shadow: 0 24px 80px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.07);
          transform-origin: bottom right;
          animation: cw-open 0.3s cubic-bezier(.34,1.56,.64,1);
        }
        @keyframes cw-open {
          from { transform: scale(0.7); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }

        /* Header */
        .cw-header {
          padding: 20px 22px 16px;
          background: #111;
          border-bottom: 1px solid rgba(255,255,255,0.06);
          flex-shrink: 0;
        }
        .cw-header-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 4px;
        }
        .cw-title {
          font-family: 'Syne', sans-serif;
          font-weight: 800;
          font-size: 16px;
          color: #fff;
          letter-spacing: -0.3px;
        }
        .cw-status {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          color: rgba(255,255,255,0.4);
          font-weight: 400;
        }
        .cw-status-dot {
          width: 6px; height: 6px;
          background: #e8ff47;
          border-radius: 50%;
        }
        .cw-close {
          background: rgba(255,255,255,0.07);
          border: none;
          color: rgba(255,255,255,0.5);
          width: 28px; height: 28px;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background 0.15s, color 0.15s;
        }
        .cw-close:hover { background: rgba(255,255,255,0.12); color: #fff; }
        .cw-accent-bar {
          height: 2px;
          background: linear-gradient(90deg, #e8ff47, #00e5ff);
          border-radius: 2px;
          margin-top: 12px;
          width: 40px;
        }

        /* Messages */
        .cw-messages {
          flex: 1;
          overflow-y: auto;
          padding: 16px 16px 8px;
          display: flex;
          flex-direction: column;
          gap: 10px;
          scrollbar-width: thin;
          scrollbar-color: rgba(255,255,255,0.1) transparent;
        }
        .cw-messages::-webkit-scrollbar { width: 4px; }
        .cw-messages::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 4px; }

        .cw-msg {
          display: flex;
          flex-direction: column;
          max-width: 82%;
          animation: cw-msg-in 0.2s ease;
        }
        @keyframes cw-msg-in {
          from { transform: translateY(6px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        .cw-msg.user { align-self: flex-end; align-items: flex-end; }
        .cw-msg.assistant { align-self: flex-start; align-items: flex-start; }

        .cw-bubble {
          padding: 10px 14px;
          border-radius: 16px;
          font-size: 13.5px;
          line-height: 1.5;
          font-weight: 400;
        }
        .cw-msg.user .cw-bubble {
          background: linear-gradient(135deg, #e8ff47, #c8e000);
          color: #0a0a0a;
          border-bottom-right-radius: 4px;
          font-weight: 500;
        }
        .cw-msg.assistant .cw-bubble {
          background: #1c1c1c;
          color: rgba(255,255,255,0.88);
          border-bottom-left-radius: 4px;
          border: 1px solid rgba(255,255,255,0.06);
        }

        /* Typing */
        .cw-typing {
          display: flex;
          align-items: center;
          gap: 4px;
          padding: 12px 14px;
          background: #1c1c1c;
          border-radius: 16px;
          border-bottom-left-radius: 4px;
          border: 1px solid rgba(255,255,255,0.06);
          width: fit-content;
        }
        .cw-typing span {
          width: 6px; height: 6px;
          background: rgba(255,255,255,0.3);
          border-radius: 50%;
          animation: cw-bounce 1.2s infinite;
        }
        .cw-typing span:nth-child(2) { animation-delay: 0.2s; }
        .cw-typing span:nth-child(3) { animation-delay: 0.4s; }
        @keyframes cw-bounce {
          0%, 60%, 100% { transform: translateY(0); }
          30% { transform: translateY(-5px); background: #e8ff47; }
        }

        /* Input */
        .cw-input-area {
          padding: 12px 14px 16px;
          background: #111;
          border-top: 1px solid rgba(255,255,255,0.06);
          display: flex;
          gap: 8px;
          align-items: flex-end;
        }
        .cw-input {
          flex: 1;
          background: #1c1c1c;
          border: 1px solid rgba(255,255,255,0.08);
          border-radius: 12px;
          color: #fff;
          font-family: 'DM Sans', sans-serif;
          font-size: 13.5px;
          padding: 10px 14px;
          resize: none;
          outline: none;
          transition: border-color 0.15s;
          max-height: 100px;
          line-height: 1.4;
        }
        .cw-input::placeholder { color: rgba(255,255,255,0.25); }
        .cw-input:focus { border-color: rgba(232,255,71,0.4); }

        .cw-send {
          width: 40px; height: 40px;
          border-radius: 11px;
          background: #e8ff47;
          border: none;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          transition: transform 0.15s, background 0.15s;
        }
        .cw-send:hover { transform: scale(1.06); background: #d4eb2a; }
        .cw-send:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }
      `}</style>

      <div className="cw-root">
        {open && (
          <div className="cw-window">
            {/* Header */}
            <div className="cw-header">
              <div className="cw-header-top">
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div className="cw-title">{BOT_NAME}</div>
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div className="cw-status">
                    <div className="cw-status-dot" />
                    Online
                  </div>
                  <button className="cw-close" onClick={() => setOpen(false)}>
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                      <path d="M1 1l10 10M11 1L1 11" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
                    </svg>
                  </button>
                </div>
              </div>
              <div className="cw-accent-bar" />
            </div>

            {/* Messages */}
            <div className="cw-messages">
              {messages.map((m, i) => (
                <div key={i} className={`cw-msg ${m.role}`}>
                  <div className="cw-bubble">{m.content}</div>
                </div>
              ))}
              {loading && (
                <div className="cw-msg assistant">
                  <div className="cw-typing">
                    <span /><span /><span />
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            {/* Input */}
            <div className="cw-input-area">
              <textarea
                className="cw-input"
                rows={1}
                placeholder="Type a message..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKey}
              />
              <button className="cw-send" onClick={sendMessage} disabled={loading || !input.trim()}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <path d="M22 2L11 13M22 2L15 22L11 13M22 2L2 9L11 13" stroke="#0a0a0a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            </div>
          </div>
        )}

        {/* FAB */}
        <button className="cw-fab" onClick={() => setOpen((o) => !o)}>
          {!open && <div className="cw-dot" />}
          {open ? (
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" color="white">
              <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"/>
            </svg>
          ) : (
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" color="white">
              <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          )}
        </button>
      </div>
    </>
  );
}
