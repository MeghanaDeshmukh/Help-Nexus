// app/api/chat/route.js  (Next.js App Router)
// OR pages/api/chat.js   (Next.js Pages Router — see bottom of file)

// ─── APP ROUTER VERSION ───────────────────────────────────────────────────────
import { NextResponse } from "next/server";

const OLLAMA_URL = process.env.OLLAMA_URL || "http://localhost:11434";
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || "llama3";

export async function POST(req) {
  try {
    const { messages, systemPrompt } = await req.json();

    const response = await fetch(`${OLLAMA_URL}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: OLLAMA_MODEL,
        stream: false,
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
      }),
    });

    if (!response.ok) {
      throw new Error(`Ollama error: ${response.statusText}`);
    }

    const data = await response.json();
    const reply = data.message?.content || "Sorry, I couldn't generate a response.";

    return NextResponse.json({ reply });
  } catch (error) {
    console.error("Chat API error:", error);
    return NextResponse.json(
      { reply: "Sorry, the AI is temporarily unavailable. Please try again shortly." },
      { status: 500 }
    );
  }
}


// ─── PAGES ROUTER VERSION ─────────────────────────────────────────────────────
// If you use /pages/api/chat.js instead, replace the above with:
//
// export default async function handler(req, res) {
//   if (req.method !== "POST") return res.status(405).end();
//   try {
//     const { messages, systemPrompt } = req.body;
//     const response = await fetch(`${OLLAMA_URL}/api/chat`, {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({
//         model: OLLAMA_MODEL,
//         stream: false,
//         messages: [{ role: "system", content: systemPrompt }, ...messages],
//       }),
//     });
//     const data = await response.json();
//     res.status(200).json({ reply: data.message?.content || "No response." });
//   } catch (err) {
//     res.status(500).json({ reply: "AI unavailable." });
//   }
// }
