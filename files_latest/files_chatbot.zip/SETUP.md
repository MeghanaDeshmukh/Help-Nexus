# 🤖 Private AI Chatbot — Setup Guide

A fully private AI chatbot for your Next.js website, powered by Ollama (runs locally on your server — no data sent to third parties).

---

## 📦 Files Included

| File | Purpose |
|---|---|
| `ChatWidget.jsx` | Drop-in React chat widget for your site |
| `route.js` | Next.js API route that talks to Ollama |

---

## 🚀 Quick Setup

### Step 1 — Install Ollama

**On your machine (dev) or VPS (production):**
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

### Step 2 — Pull a model

```bash
ollama pull llama3        # Recommended: smart & fast (~4GB)
# OR
ollama pull mistral       # Lighter alternative (~4GB)
```

### Step 3 — Add files to your Next.js project

```
your-nextjs-app/
├── app/
│   ├── api/
│   │   └── chat/
│   │       └── route.js        ← copy here (App Router)
│   └── layout.js
├── components/
│   └── ChatWidget.jsx           ← copy here
```

### Step 4 — Add the widget to your layout

```jsx
// app/layout.js
import ChatWidget from "@/components/ChatWidget";

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        {children}
        <ChatWidget />   {/* ← adds chat to every page */}
      </body>
    </html>
  );
}
```

### Step 5 — Set environment variables (optional)

Create `.env.local`:
```env
OLLAMA_URL=http://localhost:11434   # default
OLLAMA_MODEL=llama3                 # or mistral
```

### Step 6 — Run it!

```bash
# Terminal 1: Start Ollama
ollama serve

# Terminal 2: Start Next.js
npm run dev
```

Visit your site — the chat bubble appears in the bottom-right corner! 🎉

---

## 🌐 Going to Production (VPS)

1. Rent a VPS with at least **8GB RAM** (e.g. DigitalOcean $48/mo, Hetzner CX32 ~€13/mo)
2. Install Ollama on the VPS
3. Set `OLLAMA_URL=http://your-vps-ip:11434` in your production env
4. Optionally add a firewall rule so only your Next.js server can reach Ollama

---

## ✏️ Customization

### Change the bot's name & personality
In `ChatWidget.jsx`, edit:
```js
const BOT_NAME = "AI Assistant";      // ← change name
const SYSTEM_PROMPT = `...`;           // ← change personality/knowledge
```

### Add your business info to the prompt
```js
const SYSTEM_PROMPT = `You are a helpful assistant for Acme Corp.
We sell premium widgets. Our pricing starts at $99/month.
Office hours: Mon-Fri 9am-5pm EST.
For urgent issues, email support@acmecorp.com.
...`;
```

---

## 🔒 Privacy

- ✅ All AI processing happens on YOUR server
- ✅ No API keys needed
- ✅ No data sent to OpenAI, Anthropic, or any third party
- ✅ Conversation history stays in the user's browser session only
